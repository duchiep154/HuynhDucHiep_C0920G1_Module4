package vn.codegym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class i18nApplicationTests {

    @Test
    void contextLoads() {
    }

}
