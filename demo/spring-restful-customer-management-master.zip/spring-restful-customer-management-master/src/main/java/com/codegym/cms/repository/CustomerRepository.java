package com.codegym.cms.repository;

import com.codegym.cms.model.Customer;

public interface CustomerRepository extends Repository<Customer> {
}